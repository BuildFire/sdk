# Bluetooth ExamplePlugin
This is a simple example on how to communicate with an Arduino via a buildfire.js

Using this buildfire.js service API https://github.com/BuildFire/sdk/wiki/BuildFire-Bluetooth-Service
We created a simple control that both reads and writes to a bluetooth enabled Arduino device that has a display unit and LED light
The plugin simply turns the light on and off and the display shows a counter of how many times the LED turned on

This simple example opens up your BuildFire app to the world of IoT (internet of things)

Have fun!
