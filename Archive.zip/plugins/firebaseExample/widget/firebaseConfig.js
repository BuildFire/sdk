var firebaseConfig = {
    apiKey: "AIzaSyDKIrqpLeskOIkjHJszZJVK5jXkwPKeE1E",
    authDomain: "example-project-b39c5.firebaseapp.com",
    projectId: "example-project-b39c5",
    storageBucket: "example-project-b39c5.appspot.com",
    messagingSenderId: "164683799430",
    appId: "1:164683799430:web:f7ff4bab442f2be0d26a07"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);