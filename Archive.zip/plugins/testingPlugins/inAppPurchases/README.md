# inAppPurchases

A plugin to test products & subscriptions on devices
