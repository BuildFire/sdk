angular.module('plugin')
    .controller('urlCtrl', ['$rootScope', '$scope', '$location', '$timeout', 'userDataService', 'buildfire',
        function ($rootScope, $scope, $location, $timeout, userDataService, buildfire) {

}]);
