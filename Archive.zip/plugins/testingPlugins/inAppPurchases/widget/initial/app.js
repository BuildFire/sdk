angular.module('plugin', ['ngRoute', 'oc.lazyLoad', 'ngAnimate']).config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when('/url', {
            templateUrl: 'lazy/templates/url.html',
            controller: 'urlCtrl',
            resolve: {
                lazy: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load({
                        name: 'plugin',
                        files: ['lazy/ctrls/urlCtrl.js', 'lazy/css/animate.css']
                    });
                }]
            }
        })
        .otherwise({
            redirectTo: '/'
        });
}]).factory('buildfire', [function () {
    if (typeof buildfire !== 'undefined') {
        return buildfire;
    }
}]);
