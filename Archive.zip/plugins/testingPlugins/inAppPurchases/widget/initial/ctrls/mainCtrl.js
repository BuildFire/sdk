angular.module('plugin')
    .controller('mainCtrl', ['$window', '$rootScope', '$scope', '$location', '$timeout', 'buildfire',
    function ($window, $rootScope, $scope, $location, $timeout, buildfire) {

        buildfire.services.commerce.inAppPurchase.getProducts(function(err, result) {
          if(err) {
            $scope.productResult = err;
          } else {
            $scope.products = result;
          }
          if (!$scope.$$phase)$scope.$digest();
        });

        buildfire.services.commerce.inAppPurchase.getSubscriptions(function(err, result) {
          if(err) {
            $scope.subscriptionResult = err;
          } else {
            $scope.subscriptions = result;
          }
          if (!$scope.$$phase)$scope.$digest();
        });

        $scope.checkProduct = function(){
          buildfire.services.commerce.inAppPurchase.checkIsPurchased({type: 'products', name: $scope.selectedProduct.name},function(err, result) {
            if(err) {
              $scope.productResult = err;
            } else {
              $scope.productResult = result;
            }
            if (!$scope.$$phase)$scope.$digest();
          });
        };

        $scope.checkSubscription = function(){
          buildfire.services.commerce.inAppPurchase.checkIsPurchased({type: 'subscriptions', name: $scope.selectedSubscription.name},function(err, result) {
            if(err) {
              $scope.subscriptionResult = err;
            } else {
              $scope.subscriptionResult = result;
            }
            if (!$scope.$$phase)$scope.$digest();
          });
        };

        $scope.reload = function() {
          window.location.reload();
        };

}]);
