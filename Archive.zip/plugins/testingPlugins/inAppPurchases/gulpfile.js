const gulp = require('gulp');
const rename = require('gulp-rename');
const del = require('del');
const minHTML = require('gulp-htmlmin');
const minifyCSS = require('gulp-csso');
const concat = require('gulp-concat');
const strip = require('gulp-strip-comments');
const htmlReplace = require('gulp-html-replace');
const uglify = require('gulp-uglify');
const eslint = require('gulp-eslint');
const imagemin = require('gulp-imagemin');
const gulpSequence = require('gulp-sequence');
const postcss = require('gulp-postcss');
const uncss = require('postcss-uncss');

const destinationFolder = releaseFolder();

function releaseFolder() {
    var arr = __dirname.split("/");
    var fldr = arr.pop();
    arr.push(fldr + "_release");
    return arr.join("/");
}

console.log(">> Building to ", destinationFolder);


const cssTasks = [
    {name: "widgetInitialCSS", src: "widget/initial/**/*.css", dest: "/widget"}
    , {name: "widgetLazyCSS", src: "widget/lazy/**/*.css", dest: "", bundle: false}
    , {name: "controlContentCSS", src: "control/content/**/*.css", dest: "/control/content"}
    , {name: "controlDesignCSS", src: "control/design/**/*.css", dest: "/control/design"}
    , {name: "controlSettingsCSS", src: "control/settings/**/*.css", dest: "/control/settings"}
];

cssTasks.forEach(function (task) {
    /*
     Define a task called 'css' the recursively loops through
     the widget and control folders, processes each CSS file and puts
     a processes copy in the 'build' folder
     note if the order matters you can import each css separately in the array

     */
    gulp.task(task.name, function () {

        var plugins = [
            uncss({
                ignore : ['.btn-checkin.active', '.menu-main-toggle ul li > ul li.active > a', '.collapsed', '.collapse', '.app-item-user .overlay.fade-in'],
                html: ['widget/index.html', 'widget/lazy/**/*.html']
            })
        ];

        var gulpTask = gulp.src(task.src, {base: '.'});

        // uncss
        if (task.bundle !== false) gulpTask = gulpTask.pipe(postcss(plugins).on('error', function (e) {
            console.error(e);
        }));

        /// minify the CSS contents
        gulpTask = gulpTask.pipe(minifyCSS().on('error', function (e) {
            console.error(e);
        }));

        ///merge
        if (task.bundle !== false) gulpTask = gulpTask.pipe(concat('styles.min.css').on('error', function (e) {
            console.error(e);
        }));

        /// write result to the 'build' folder
        gulpTask = gulpTask.pipe(gulp.dest(destinationFolder + task.dest).on('error', function (e) {
            console.error(e);
        }));

        return gulpTask;
    });
});

const jsTasks = [
    {name: "widgetInitialLibJS", src: [
        "widget/initial/libs/angular.min.js",
        "widget/initial/libs/angular-route.min.js",
        "widget/initial/libs/angular-animate.min.js",
        "widget/initial/libs/ocLazyLoad.min.js",
        "widget/initial/app.js",
        "widget/initial/ctrls/*.js"], dest: "/widget"},
    {name: "widgetLazyJS", src: "widget/lazy/**/*.js", dest: "", bundle: false},
    {name: "controlContentJS", src: "control/content/**/*.js", dest: "/control/content"},
    {name: "controlDesignJS", src: "control/design/**/*.js", dest: "/control/design"},
    {name: "controlSettingsJS", src: "control/settings/**/*.js", dest: "/control/settings"}
];

jsTasks.forEach(function (task) {
    gulp.task(task.name, function () {
        var gulpTask = gulp.src(task.src, {base: '.'});

        /// obfuscate and minify the JS files
        gulpTask = gulpTask.pipe(uglify().on('error', function (e) {
            console.error(e);
        }));

        /// merge all the JS files together. If the
        /// order matters you can pass each file to the function
        /// in an array in the order you like
        if (task.bundle !== false) gulpTask = gulpTask.pipe(concat('scripts.min.js').on('error', function (e) {
            console.error(e);
        }));

        ///output here
        gulpTask = gulpTask.pipe(gulp.dest(destinationFolder + task.dest).on('error', function (e) {
            console.error(e);
        }));

        return gulpTask;

    });

});

gulp.task('lint', () => {
    // ESLint ignores files with "node_modules" paths.
    // So, it's best to have gulp ignore the directory as well.
    // Also, Be sure to return the stream from the task;
    // Otherwise, the task may end before the stream has finished.
    return gulp.src(['widget/**/*.js', 'control/**/*.js', '!widget/**/*.min.js', '!control/**/*.min.js'])
        // eslint() attaches the lint output to the "eslint" property
        // of the file object so it can be used by other modules.
        .pipe(eslint({
            "env": {
                "browser": true,
                "es6": true
            },
            "extends": "eslint:recommended",
            "parserOptions": {
                "sourceType": "module"
            },
            "rules": {
                "semi": [
                    "error",
                    "always"
                ],
                "no-console": [
                    "off"
                ]
            }
        }))
        // eslint.format() outputs the lint results to the console.
        // Alternatively use eslint.formatEach() (see Docs).
        .pipe(eslint.format().on('error', function (e) {
            console.error(e);
        }))
        // To have the process exit with an error code (1) on
        // lint error, return the stream and pipe to failAfterError last.
        .pipe(eslint.failAfterError().on('error', function (e) {
            console.error(e);
        }));
});

gulp.task('clean', function () {
    return del([destinationFolder], {force: true});
});

/*
 Define a task called 'html' the recursively loops through
 the widget and control folders, processes each html file and puts
 a processes copy in the 'build' folder
 */
gulp.task('html', function () {
    return gulp.src(['widget/**/*.html', 'widget/**/*.htm', 'control/**/*.html', 'control/**/*.htm'], {base: '.'})
        /// replace all the <!-- build:bundleJSFiles  --> comment bodies
        /// with scripts.min.js with cache buster
        .pipe(htmlReplace({
            bundleJSFiles: "scripts.min.js?v=" + (new Date().getTime())
            , bundleCSSFiles: "styles.min.css?v=" + (new Date().getTime())
        }))

        /// then strip the html from any comments
        .pipe(minHTML({removeComments: true, collapseWhitespace: true}))

        /// write results to the 'build' folder
        .pipe(gulp.dest(destinationFolder));
});

gulp.task('resources', function () {
    return gulp.src(['resources/*', 'plugin.json'], {base: '.'})
        .pipe(gulp.dest(destinationFolder));
});

gulp.task('images', function () {
    return gulp.src(['**/.images/**'], {base: '.'})
        .pipe(imagemin())
        .pipe(gulp.dest(destinationFolder));
});

// css image are image referenced by CSS and all should be moved to same generated styles.min.css path
gulp.task('cssImages', function () {
    return gulp.src(['widget/initial/assets/css/images/**'], {base: '.'})
        .pipe(imagemin())
        .pipe(rename({dirname: 'widget/images'}))
        .pipe(gulp.dest(destinationFolder));
});

// direct images are images used in <img> tags
gulp.task('directImages', function () {
    return gulp.src(['widget/initial/assets/images/**'], {base: '.'})
        .pipe(imagemin())
        .pipe(gulp.dest(destinationFolder));
});

var buildTasksToRun = ['html', 'resources', 'images', 'cssImages', 'directImages'];

cssTasks.forEach(function (task) {
    buildTasksToRun.push(task.name)
});
jsTasks.forEach(function (task) {
    buildTasksToRun.push(task.name)
});

gulp.task('build', gulpSequence('lint', 'clean', buildTasksToRun));
