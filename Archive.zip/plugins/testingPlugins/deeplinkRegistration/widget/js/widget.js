class Widget {
  constructor() {
     this.init();
  }
  
 // To create a random id if needed
  uuidv4(m = Math, d = Date, h = 16, s = (s) => m.floor(s).toString(h)) {
    return s(d.now() / 1000) + " ".repeat(h).replace(/./g, () => s(m.random() * h));
  }

  init() {
    this.submitButton = document.querySelector('.add-record__submit');
    document.querySelector('.add-record').addEventListener('submit', (e) => {
      e.preventDefault();
      const deeplinkId = document.querySelector('#deeplinkId');
      const deeplinkData = document.querySelector('#deeplinkData');
      const nameInput = document.querySelector('#nameInput');
      const imageUrl = document.querySelector('#imageUrl');

      const recordData = {
        name: nameInput.value, 
        deeplinkData: {val: deeplinkData.value}, 
        id: deeplinkId.value, 
        imageUrl: imageUrl.value, 
      };
        buildfire.deeplink.registerDeeplink(recordData, (err, result) => {
          if(err) return console.log(err);
          console.log('INSERT DEEPLINKT', result);
          this.records.push(result);
          this.renderRecords();
        })
    })

    buildfire.deeplink.getAllDeeplinks({}, (err, res) => {
      if(err) return console.log(err);
      if(res) {
        console.log(res);
        this.records = res;
        this.renderRecords()
      }
    });


    document.querySelector('.list-view').addEventListener('click', ({target}) => {
      if(target && target.dataset && target.dataset.recordId) {
        const targetId = target.dataset.recordId;
        if(targetId) {
          buildfire.deeplink.unregisterDeeplink(targetId, (err, result) => {
            if(err) return console.log(err);
            console.log('DELETING DEEPLINK', result);
            this.records = this.records.filter(rec => rec.data.deeplinkId !== targetId);
            this.renderRecords()
          });
        }
      }
    }) 
  }


  renderRecords() {
    const listView = document.querySelector('.list-view');
    listView.innerHTML = '';
    this.records.forEach(rec => {
      const recordMarkup = `<div class="record" >
      <span class="record__name" >name : ${rec.data.name}</span>
      <span class="record__name" >deeplinkData : ${rec.data.deeplinkData.val}</span>
      <div class="record__actions" >
      <span class="record__delete"  data-record-id="${rec.data.deeplinkId}" >X</span>
      </div>
      </div>`;
      listView.innerHTML += recordMarkup;
    })

  }
}

