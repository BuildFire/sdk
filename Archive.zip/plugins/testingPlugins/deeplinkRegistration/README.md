# deeplinkRegistration 
This plugin is for testing deeplink actions (get/register/update/unregister) 
