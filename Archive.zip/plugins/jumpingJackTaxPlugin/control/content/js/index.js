let loggedInUser;
let currentTaxProfessional;
let coordinates = [];
let listUsers = [];
let savedScroll = 0;
const taxProfessionalPaginationData = {
  page: 0,
  loading: false,
};
tinymce.init({ selector: "#descriptionTextArea",
setup:function(ed) {
    ed.on('change', function(e) {
        callUpdate();
    });
} });

const debounce = (fn, time) => {
    let timeout;
    return function (...args) {
        const functionCall = () => fn.apply(this, args);
        clearTimeout(timeout);
        timeout = setTimeout(functionCall, time);
    };
};

authManager.onUserChange = (user) => {
    loggedInUser = user;
    copyInfo();
    search();
};

const copyInfo = () => {
    let taxPros = [];
    let page = 0, pageSize = 50;

    let get = function() {
        buildfire.publicData.search({ recordCount: true, pageSize, page }, 'taxProfessional', (err, data) => {
            taxPros = taxPros.concat(data.result);
            if(taxPros.length < data.totalRecord) {
                page++;
                get();
            } else {
                buildfire.appData.search({recordCount:true}, 'taxInfo', (err, data) => {
                    if(data.result.length === taxPros.length) return;
                    else {
                        taxPros.map(item => {
                            let toInsert = {
                                find: item.id,
                                bookingUrl: item.data.bookingUrl,
                                user: item.data.buildfireUser
                            };
                            buildfire.appData.insert(toInsert, 'taxInfo', console.log);
                        });
                    }
                });
            }
        });
    };

    get();
};

const registerEvent = (title, key, description) => {
    buildfire.analytics.registerEvent({
        title: title,
        key: key,
        description: description
    }, { silentNotification: true });
};

registerEvent('Contact', 'contact', 'Contact user');
registerEvent('Jack PRO', 'jackPro', 'Visited Jack PRO profile');
registerEvent('Non Jack PRO', 'nonJackPro', 'Visited non Jack PRO profile');

const search = (query, isFresh = true) => {
    if (taxProfessionalPaginationData.loading) return;
    taxProfessionalPaginationData.loading = true;
    let items = document.getElementById("items");
    if (isFresh) {
      taxProfessionalPaginationData.page = 0;
      items.innerHTML = "";
    }

    if (!query) query = {
        filter: {
            $and: [
                {
                    "_buildfire.index.array1": 2
                }
            ]
        }
    };

    if (searchTextField.value) {
        query.filter.$and.push({ "_buildfire.index.string1": { $regex: searchTextField.value, $options: 'i' } });
    }

    if (sortBySelect.value)
        query.sort = getSortQuery();

    query.pageSize = 50;
    query.page = taxProfessionalPaginationData.page;
    TaxProfessionals.search(query, (err, taxProfessionals) => {
        taxProfessionalPaginationData.loading = false;
        if (err || !taxProfessionals) return;
        listUsers = listUsers.concat(taxProfessionals.result);
        taxProfessionals.result.forEach(taxProfessional => {
            let taxProfessionalUI = createTaxRow(taxProfessional);
            items.appendChild(taxProfessionalUI);
        });

        taxProfessionalPaginationData.page++;
        buildfire.components.ratingSystem.injectRatings({ hideAverage: true, showRatingsOnClick: true });

        if (taxProfessionals.length === 0) {
            items.innerHTML = "Add your first tax professional by clicking button `+ ADD NEW PROFESSIONAL` above";
        }
    });
};

document.getElementById('listScreen').addEventListener("scroll", function (ev) {
  let element = ev.target;
  savedScroll=element.scrollTop;
  if (element.scrollHeight - ~~element.scrollTop === element.clientHeight) search(null, false);
});

authManager.enforceLogin();

const searchTextField = new mdc.textField.MDCTextField(document.querySelector('.search-input'));

const sortBySelect = new mdc.select.MDCSelect(document.querySelector(".mdc-select"));

sortBySelect.listen("MDCSelect:change", () => {
    search();
});

const getSortQuery = () => {
    switch (sortBySelect.value) {
        case "nameAZ":
            return { firstName: 1 };
            break;
        case "nameZA":
            return { firstName: -1 };
            break;
        case "lastAZ":
            return { lastName: 1 };
            break;
        case "lastZA":
            return { lastName: -1 };
            break;
        case "oldNew":
            return { createdOn: 1 };
            break;
        case "newOld":
            return { createdOn: -1 };
            break;

        default:
            return {};
            break;
    }
};

const firstNameTextField = new mdc.textField.MDCTextField(document.querySelector('#firstNameInput'));
const lastNameTextField = new mdc.textField.MDCTextField(document.querySelector('#lastNameInput'));
const addressTextField = new mdc.textField.MDCTextField(document.querySelector('#addressInput'));
const shareUrlTextField = new mdc.textField.MDCTextField(document.querySelector('#shareUrlInput'));

addresInputField.addEventListener("change", () => {
    getCoordinates(addressTextField.value);
    callUpdate();
});

const taxReturnsFiledTextField = new mdc.textField.MDCTextField(document.querySelector('#taxReturnsFiledInput'));
const bookingUrlTextField = new mdc.textField.MDCTextField(document.querySelector('#bookingUrlInput'));

const isActiveSwitch = new mdc.switchControl.MDCSwitch(document.querySelector('#isActiveSwitch'));
isActiveSwitch.checked = true;

const checkBoxes = [
    "#englishCheckbox",
    "#spanishCheckbox",
    "#virtualCheckbox",
    "#inOfficeCheckbox",
    "#conciergeCheckbox",
    "#cert1Checkbox",
    "#cert2Checkbox",
    "#cert3Checkbox",
];

const checkBoxControls = checkBoxes.map(id => new mdc.checkbox.MDCCheckbox(document.querySelector(id)));

const isProSwitch = new mdc.switchControl.MDCSwitch(document.querySelector('#isProSwitch'));

let searchUsersButton = document.getElementById("searchUsersButton");
let selectedBuildfireUser = document.getElementById("selectedBuildfireUser");
searchUsersButton.addEventListener("click", () => {
    buildfire.auth.showUsersSearchDialog({}, (error, users) => {
        if (error) return console.error(error);
        let selectedUser = users && users.users && users.users[0] ? users.users[0] : null;
        if (!selectedUser) return console.log("No user selected");

        selectedBuildfireUser.innerHTML = "Selected User: " + selectedUser.displayName;
        selectedBuildfireUser.dataset.userObject = JSON.stringify(selectedUser);
        callUpdate();
    });
});

const getCoordinates = (address) => {
    let saveButton = document.getElementById("saveButton");
    let saveButtonTop = document.getElementById("saveButtonTop");
    saveButton.setAttribute("disabled",true);
    saveButtonTop.setAttribute("disabled",true);
    const apiKey = buildfire.getContext().apiKeys.googleMapKey;
    let url = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${apiKey}`;
    fetch(url).then(res => {
        if (res.ok) return res.json();
    }).then(res => {
        saveButton.removeAttribute("disabled");
        saveButtonTop.removeAttribute("disabled");
        if (!res || !res.results || !res.results[0]) return coordinates = [];
        let result = res.results[0];
        coordinates[0] = result.geometry.location;
        let strings = result.formatted_address.split(',');
        coordinates[1] = strings[strings.length - 1].trim();
        registerEvent(coordinates[1], 'country_' + coordinates[1], 'Registered new state');
    });
};

const navigateTo = (screenId) => {
    let listScreen = document.getElementById("listScreen");
    let addTaxProfessionalScreen = document.getElementById("addTaxProfessionalScreen");
    window.scroll(0,0);
    switch (screenId) {
        case "listScreen":
            listScreen.style.display = "block";
            addTaxProfessionalScreen.style.display = "none";
            break;

        case "addTaxProfessionalScreen":
            addTaxProfessionalScreen.style.display = "block";
            listScreen.style.display = "none";
            break;

        default:
            break;
    }
};

let addProfessionalButton = document.getElementById("addProfessionalButton");
addProfessionalButton.addEventListener("click", () => {
    coordinates = [];
    buildfire.messaging.sendMessageToWidget({state:"edit",open:null});
    navigateTo("addTaxProfessionalScreen");
    let shareUrlContainer = document.getElementById("shareUrlContainer");
    shareUrlContainer.style.display = "none";
});

let imageCircle = document.getElementById("imageCircle");
imageCircle.addEventListener("click", () => {
    const options = {
        showIcons: false,
        multiSelection: false
    };
    const callback = function (error, result) {
        if (error) return console.error(error);
        if (result && result.selectedFiles && result.selectedFiles[0]) {
            let imageCircleImg = document.getElementById("imageCircleImg");
            imageCircleImg.src = result.selectedFiles[0];
            imageCircleImg.style.display = "block";
            callUpdate();
        }
    };

    buildfire.imageLib.showDialog(options, callback);
});

const callUpdate = () =>{
    let taxProfessional=createTaxProObjectToSave();
    buildfire.messaging.sendMessageToWidget({state:"update",open:taxProfessional});
};

const createTaxProObjectToSave = () =>{
    let languages = [];
    if (checkBoxControls[0].checked) languages.push("english");
    if (checkBoxControls[1].checked) languages.push("spanish");

    let serviceTypes = [];
    if (checkBoxControls[2].checked) serviceTypes.push("virtual");
    if (checkBoxControls[3].checked) serviceTypes.push("inoffice");
    if (checkBoxControls[4].checked) serviceTypes.push("concierge");

    let certificates = [];
    if (checkBoxControls[5].checked) certificates.push("cert1");
    if (checkBoxControls[6].checked) certificates.push("cert2");
    if (checkBoxControls[7].checked) certificates.push("cert3");

    let taxProfessional = new TaxProfessional({
        id: currentTaxProfessional ? currentTaxProfessional.id : null,
        data: {
            isActive: isActiveSwitch.checked,
            firstName: firstNameTextField.value,
            lastName: lastNameTextField.value,
            address: addressTextField.value,
            isPro: isProSwitch.checked,
            taxReturnsFiled: taxReturnsFiledTextField.value,
            bookingUrl: bookingUrlTextField.value,
            profileImage: imageCircleImg.src || "https://app.buildfire.com/app/media/avatar.png",
            description: tinymce.activeEditor.getContent(),
            languages,
            serviceTypes,
            certificates,
            location: coordinates[0],
            state: coordinates[1],
            buildfireUser: (selectedBuildfireUser.dataset.userObject ? JSON.parse(selectedBuildfireUser.dataset.userObject) : null)
        }
    });
    return taxProfessional;
};

const onSave = () => {
    let firstTimeInfo = false;
    let saveButton = document.getElementById("saveButton");
    let saveButtonTop = document.getElementById("saveButtonTop");
    saveButton.setAttribute("disabled",true);
    saveButtonTop.setAttribute("disabled",true); 
    let taxProfessional=createTaxProObjectToSave();
    const callback = (err, data) => {
        if(firstTimeInfo) {
            let toInsert = {
                find: data.id,
                bookingUrl: taxProfessional.bookingUrl,
                user: taxProfessional.buildfireUser
            };
            buildfire.appData.insert(toInsert, 'taxInfo', console.log);
            firstTimeInfo = false;
        }
        let displayName = taxProfessional.firstName + ' ' + taxProfessional.lastName;
        registerEvent(displayName, 'user_' + displayName, 'Visited user');
        saveButton.removeAttribute("disabled");
        saveButtonTop.removeAttribute("disabled"); 
        buildfire.messaging.sendMessageToWidget({state:"list",open:1});
        navigateTo("listScreen");
        currentTaxProfessional = null;
        fillForm();
        search();
    };
    if (taxProfessional.id) {
        buildfire.appData.search({filter: {"$json.find": taxProfessional.id}}, 'taxInfo', (err, result) => {
            if(result && result.length) {
                let toUpdate = {
                    find: taxProfessional.id,
                    bookingUrl: taxProfessional.bookingUrl,
                    user: taxProfessional.buildfireUser
                };
                buildfire.appData.update(result[0].id, toUpdate, 'taxInfo', console.log);
            }
        });
        TaxProfessionals.set(loggedInUser, taxProfessional, callback);
    } else {
        firstTimeInfo = true;
        TaxProfessionals.add(loggedInUser, taxProfessional, callback);
    }
};

let saveButton = document.getElementById("saveButton");
let saveButtonTop = document.getElementById("saveButtonTop");
saveButton.addEventListener("click", onSave);
saveButtonTop.addEventListener("click", onSave);

const onCancel = () => {
    if (currentTaxProfessional && currentTaxProfessional.id)
        buildfire.messaging.sendMessageToWidget({state:"list",open:1});
    navigateTo("listScreen");
    currentTaxProfessional = null;
    fillForm();
};

let cancelButton = document.getElementById("cancelButton");
let cancelButtonTop = document.getElementById("cancelButtonTop");
cancelButtonTop.addEventListener("click", onCancel);
cancelButton.addEventListener("click", onCancel);

let searchButton = document.getElementById("searchButton");
searchButton.addEventListener("click", () => {
    search();
});


const createTaxRow = (taxProfessional) => {
    let container = document.createElement("div");
    container.className = "tax-pro-row";

    let image = document.createElement("img");
    image.className = "tax-pro-image";
    image.src = buildfire.imageLib.resizeImage(taxProfessional.profileImage ? taxProfessional.profileImage : "https://app.buildfire.com/app/media/avatar.png", { size: "m", aspect: "1:1" });
    container.appendChild(image);

    let nameContainer = document.createElement("div");
    nameContainer.className = "ml-1";

    let name = document.createElement("div");
    name.className = "tax-pro-name";
    name.innerText = taxProfessional.firstName + " " + taxProfessional.lastName;
    nameContainer.appendChild(name);

    let address = document.createElement("div");
    address.className = "tax-pro-address";
    address.innerText = taxProfessional.address;
    nameContainer.appendChild(address);
    container.appendChild(nameContainer);

    let reviews = document.createElement("div");
    reviews.className = "tax-pro-reviews";
    reviews.dataset.ratingId = taxProfessional.id;
    container.appendChild(reviews);

    let commandIcons = document.createElement("div");
    commandIcons.className = "command-icons";

    let editButton = document.createElement("button");
    editButton.className = "mdc-icon-button material-icons";
    editButton.innerText = "edit";
    editButton.addEventListener("click", () => {
        currentTaxProfessional = taxProfessional;
        coordinates[0] = currentTaxProfessional.location ? currentTaxProfessional.location : null;
        let idToSend=currentTaxProfessional.id;
        buildfire.messaging.sendMessageToWidget({state:"edit",open:idToSend});
        fillForm();
        navigateTo("addTaxProfessionalScreen");
        let shareUrlContainer = document.getElementById("shareUrlContainer");
        shareUrlContainer.style.display = "grid";
    });
    commandIcons.appendChild(editButton);

    let deleteButton = document.createElement("button");
    deleteButton.className = "mdc-icon-button material-icons";
    deleteButton.innerText = "clear";
    deleteButton.addEventListener("click", () => {
        buildfire.notifications.confirm({
            title: "Are you sure?"
            , message: "Are you sure you want to delete this record?"
            , confirmButton: { text: 'Yes', key: 'yes', type: 'danger' }
            , cancelButton: { text: 'No', key: 'no', type: 'default' }
        }, function (e, data) {
            if ((e && e !== 2) || (data && data.selectedButton.key) == "yes") {
                TaxProfessionals.del(loggedInUser, taxProfessional, (err, deleted) => {
                    if (err) return console.error(err);
                    buildfire.appData.search({filter: {"$json.find": taxProfessional.id}}, 'taxInfo', (err, result) => {
                        if(result && result.length) {
                            buildfire.appData.delete(result[0].id, 'taxInfo',console.log);
                            container.parentElement.removeChild(container);
                        }
                    });
                });
            };
        });
    });
    commandIcons.appendChild(deleteButton);
    container.appendChild(commandIcons);

    return container;
};

const generateShareUrlToElement = (user, element) => {
    if (!user) return;
    let link = {};
    link.title = user.firstName + " " + user.lastName + " Tax Professional";
    link.imageUrl = user.profileImage;

    link.data = {
        "userId": user.id
    };

    buildfire.deeplink.generateUrl(link, function (err, result) {
        if (err) {
            console.error(err);
        } else {
            shareUrlTextField.value = result.url;
            setTimeout(() => {
                shareUrlTextField.layout();
            }, 100);
        }
    });
};

searchInpuut.addEventListener('keyup', debounce(function (e) {
    search();
}, 300));

const fillForm = () => {
    checkBoxControls[0].checked = currentTaxProfessional ? currentTaxProfessional.languages.indexOf("english") != -1 : false;
    checkBoxControls[1].checked = currentTaxProfessional ? currentTaxProfessional.languages.indexOf("spanish") != -1 : false;

    checkBoxControls[2].checked = currentTaxProfessional ? currentTaxProfessional.serviceTypes.indexOf("virtual") != -1 : false;
    checkBoxControls[3].checked = currentTaxProfessional ? currentTaxProfessional.serviceTypes.indexOf("inoffice") != -1 : false;
    checkBoxControls[4].checked = currentTaxProfessional ? currentTaxProfessional.serviceTypes.indexOf("concierge") != -1 : false;

    let certificates = [];
    checkBoxControls[5].checked = currentTaxProfessional ? currentTaxProfessional.certificates.indexOf("cert1") != -1 : false;
    checkBoxControls[6].checked = currentTaxProfessional ? currentTaxProfessional.certificates.indexOf("cert2") != -1 : false;
    checkBoxControls[7].checked = currentTaxProfessional ? currentTaxProfessional.certificates.indexOf("cert3") != -1 : false;

    firstNameTextField.value = currentTaxProfessional ? currentTaxProfessional.firstName : "";
    lastNameTextField.value = currentTaxProfessional ? currentTaxProfessional.lastName : "";
    addressTextField.value = currentTaxProfessional ? currentTaxProfessional.address : "";
    isProSwitch.checked = currentTaxProfessional ? currentTaxProfessional.isPro : false;
    isActiveSwitch.checked = currentTaxProfessional ? currentTaxProfessional.isActive : true;
    taxReturnsFiledTextField.value = currentTaxProfessional ? currentTaxProfessional.taxReturnsFiled : "";
    bookingUrlTextField.value = currentTaxProfessional ? currentTaxProfessional.bookingUrl : "";
    selectedBuildfireUser.innerHTML = (currentTaxProfessional && currentTaxProfessional.buildfireUser ? currentTaxProfessional.buildfireUser.displayName : "None");
    selectedBuildfireUser.dataset.userObject = currentTaxProfessional ? JSON.stringify(currentTaxProfessional.buildfireUser) : null;
    imageCircleImg.src = currentTaxProfessional ? currentTaxProfessional.profileImage : "https://app.buildfire.com/app/media/avatar.png";
    imageCircleImg.style.display = "block";
    tinymce.activeEditor.setContent(currentTaxProfessional ? currentTaxProfessional.description : "");

    let shareUrlContainer = document.getElementById("shareUrlContainer");
    shareUrlContainer.style.display = "grid";
    let shareUrl = document.getElementById("shareUrl");
    generateShareUrlToElement(currentTaxProfessional, shareUrl);

    setTimeout(() => {
        firstNameTextField.layout();
        lastNameTextField.layout();
        addressTextField.layout();
        taxReturnsFiledTextField.layout();
        bookingUrlTextField.layout();
    }, 100);
};

const goForUser = (user) =>{
    currentTaxProfessional = user;
    coordinates[0] = currentTaxProfessional.location ? currentTaxProfessional.location : null;
    fillForm();
    navigateTo("addTaxProfessionalScreen");
    let shareUrlContainer = document.getElementById("shareUrlContainer");
    shareUrlContainer.style.display = "grid";
};

buildfire.messaging.onReceivedMessage = (message) => {
    switch (message.type) {
        case 'ratings':
            buildfire.components.ratingSystem.injectRatings({ hideAverage: true, showRatingsOnClick: false });
            break;
        case 'navigation':
            if(message.state=="edit"){
                let found=listUsers.find(el=>el.id==message.open);
                if(found){
                    goForUser(found);
                }else{
                    TaxProfessionals.get(message.open,(err,obj)=>{
                        if(err)console.error(err);
                        goForUser(obj);
                    });
                }
            }
            else if(message.state=="list"){
                navigateTo("listScreen");
                currentTaxProfessional = null;
                fillForm();
            }
            break;
    }
};

