export default function ui(elementType, appendTo, innerHTML, classNameArray, attributes) {
  let e = document.createElement(elementType);
  if (innerHTML) e.innerHTML = innerHTML;
  if (Array.isArray(classNameArray))
    classNameArray.forEach((c) => e.classList.add(c));
  if (appendTo) appendTo.appendChild(e);
  if(attributes && Array.isArray(attributes))
    attributes.forEach(attribute => e.setAttribute(attribute.name, attribute.value));
  return e;
}
