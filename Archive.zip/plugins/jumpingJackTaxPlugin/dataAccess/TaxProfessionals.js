class TaxProfessionals {
  /**
   * Get Database Tag
   */
  static get TAG() {
    return "taxProfessional";
  }

  /**
   * Get Single TaxProfessional
   * @param {String} id Id of taxProfessional to be retreived
   * @param {Function} callback Callback function
   */
  static get(id, callback) {
    buildfire.publicData.getById(id, TaxProfessionals.TAG, (err, record) => {
      if (err) return callback(err);
      return callback(null, new TaxProfessional(record));
    });
  }
  /**
   * Get Multiple TaxProfessionals
   * @param {Object} filters Filters object with search operators
   * @param {Function} callback Callback function
   */
  static search(filters, callback) {
    filters.recordCount = true;
    buildfire.publicData.search(
      filters,
      TaxProfessionals.TAG,
      (err, records) => {
        if (err) return callback(err);
        records.result = records.result.map((record) => new TaxProfessional(record));
        return callback(
          null,
          records
        );
      }
    );
  }
  /**
   * Add new taxProfessional
   * @param {TaxProfessional} taxProfessional Instance of taxProfessional data class
   * @param {Function} callback Callback function
   */
  static add(currentUser, taxProfessional, callback) {
    if (!(taxProfessional instanceof TaxProfessional))
      return callback(new Error("Only TaxProfessional instance can be used"));

    taxProfessional.createdBy = currentUser._id;
    taxProfessional.createdOn = new Date();

    buildfire.publicData.insert(
      taxProfessional.toJSON(),
      TaxProfessionals.TAG,
      false,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new TaxProfessional(record));
      }
    );
  }
  /**
   * Edit single taxProfessional instance
   * @param {TaxProfessional} taxProfessional Instance of taxProfessional data class
   * @param {Function} callback Callback function
   */
  static set(currentUser, taxProfessional, callback) {
    if (!(taxProfessional instanceof TaxProfessional))
      return callback(new Error("Only TaxProfessional instance can be used"));

    taxProfessional.lastUpdatedOn = new Date();
    taxProfessional.lastUpdatedBy = currentUser._id;

    buildfire.publicData.update(
      taxProfessional.id,
      taxProfessional.toJSON(),
      TaxProfessionals.TAG,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new TaxProfessional(record));
      }
    );
  }
  /**
   * Delete single taxProfessional instance
   * @param {TaxProfessional} taxProfessional Instance of taxProfessional data class
   * @param {Function} callback Callback function
   */
  static del(currentUser, taxProfessional, callback) {
    if (!(taxProfessional instanceof TaxProfessional))
      return callback(new Error("Only TaxProfessional instance can be used"));

    taxProfessional.deletedBy = currentUser._id;
    taxProfessional.deletedOn = new Date();
    taxProfessional.isActive = false;

    buildfire.publicData.update(
      taxProfessional.id,
      taxProfessional.toJSON(),
      TaxProfessionals.TAG,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new TaxProfessional(record));
      }
    );
  }
}


