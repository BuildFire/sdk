const stringsConfig = {
    screenOne: {
        title: "Tax professionals",
        subtitle: "",
        labels: {
            jackPro: {
                title: "Premium user badge",
                placeholder: "Jack Pro",
                maxLength: 20,
                defaultValue: "Jack Pro"
            },
            contactTax: {
                title: "Contact Tax Professional button",
                defaultValue: "Contact",
                placeholder: "Contact",
                maxLength: 20,
            },
        }
    },
    screenTwo: {
        title: "Ratings",
        subtitle: "",
        labels: {
            viewAll: {
                title: "View all ratings",
                placeholder: "View more",
                maxLength: 20,
                defaultValue: "View more"
            },
        }
    }

};