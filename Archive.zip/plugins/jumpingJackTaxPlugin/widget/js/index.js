let users = [], searchParams = [];
let currentUser = null, navigateToData = null, loggedUserLocation = null;
let hasMore = false, loading = false;
let page = 0;
let initialization = 0;
let slider;
let savedScroll = 0;
let pageChecker = 0;
let certMap = {
    "cert1": "+100 Hours of Education",
    "cert2": "Background Check",
    "cert3": "Outstanding Service",
};

const dialog = new mdc.dialog.MDCDialog(document.querySelector('.mdc-dialog'));

const debounce = (fn, time) => {
    let timeout;
    return function (...args) {
        const functionCall = () => fn.apply(this, args);
        clearTimeout(timeout);
        timeout = setTimeout(functionCall, time);
    };
};

authManager.onUserChange = () => {
    if (pageChecker == 1) {
        currentUser = null;
        navigateTo('listScreen');
        searchWidget();
        buildfire.messaging.sendMessageToControl({ type: 'navigation', state: 'list', open: -1 });
    }
    else if (initialization == 0) { initialization = 1; init(); }
    else searchWidget();
};
authManager.enforceLogin();

buildfire.auth.onLogout(() => {
    authManager.enforceLogin();
});

var clearBreadCrumbs = (callback) => {
    buildfire.history.get({
        pluginBreadcrumbsOnly: true
    }, function (err, result) {
        for (var i = 0; i < result.length; i++) {
            buildfire.history.pop();
            if (i == (result.length - 1)) callback();
        }
        if (result.length == 0) callback();
    });
};

buildfire.messaging.onReceivedMessage = function (message) {
    switch (message.state) {
        case "list":
            currentUser = null;
            if (!message.open || message.open != 1) {
                searchWidget();
            }
            navigateTo('listScreen');
            break;
        case "edit":
            let sended = message.open;
            if (sended == null) {
                let profile = "https://app.buildfire.com/app/media/avatar.png";
                currentUser = new TaxProfessional({ id: null });
                currentUser.profileImage = profile;
                navigateTo("detailsScreen");
            } else {
                let found = users.find(el => el.id == sended);
                if (found) {
                    goFotUser(found);
                } else {
                    TaxProfessionals.get(sended, (err, obj) => {
                        if (err) console.error(err);
                        goFotUser(obj);
                    });
                }

            }
            break;
        case "update":
            currentUser = message.open;
            formImage();
            renderUser();
            break;
    }
};

const goFotUser = (user) => {
    currentUser = user;
    formImage();
    navigateTo("detailsScreen");
};

const closeDialog = () => {
    dialog.close();
};
const formImage = () => {
    currentUser.profileImage = currentUser.profileImage.trim() ?
        buildfire.imageLib.cropImage(currentUser.profileImage,
            { size: 's', aspect: '1:1' }) : "../../../../../styles/media/avatar-placeholder.png";
};

const init = () => {
    buildfire.appearance.getAppTheme((err, obj) => {
        if (err) return console.error(err);
        document.documentElement.style.setProperty("--barColor", obj.colors.titleBarTextAndIcons);
        document.documentElement.style.setProperty("--barBGColor", obj.colors.titleBar);
        document.documentElement.style.setProperty("--color", obj.colors.bodyText);
        document.documentElement.style.setProperty("--backgroundColor", obj.colors.backgroundColor);
        document.documentElement.style.setProperty("--defaultBGColor", obj.colors.defaultTheme);
        document.documentElement.style.setProperty("--primaryTheme", obj.colors.primaryTheme);
        document.documentElement.style.setProperty("--headerText", obj.colors.headerText);
        document.documentElement.style.setProperty("--iconsColor", obj.colors.icons);
    });

    document.getElementById('scrollControl').addEventListener("scroll", function (ev) {
        if (pageChecker == 0) {
            let element = ev.target;
            savedScroll = element.scrollTop;
            if (element.scrollHeight - ~~element.scrollTop === element.clientHeight) {
                loadMore();
            }
        }
    }, false);

    var listScreen = document.getElementById("listScreen");
    listScreen.classList.add('waiting_for_location');
    buildfire.localStorage.getItem("userLocation", (err, data) => {
        if (err) return console.error(err);
        if (data) {
            if (listScreen.classList.contains('waiting_for_location')) listScreen.classList.remove('waiting_for_location');
            loggedUserLocation = JSON.parse(data);
            searchWidget();
        }
        buildfire.geo.getCurrentPosition({ enableHighAccuracy: true }, (err, position) => {
            if (err) return console.error(err);
            if (position) {
                if (listScreen.classList.contains('waiting_for_location')) listScreen.classList.remove('waiting_for_location');
                loggedUserLocation = [position.coords.longitude, position.coords.latitude];
                let locationStringified = JSON.stringify(loggedUserLocation);
                buildfire.localStorage.setItem("userLocation", locationStringified, () => { });
                if (!data) searchWidget();
            }
        });
    });

    buildfire.datastore.get('pluginData', (err, data) => {
        if (err) return console.log(err);
        if (data && data.data) navigateToData = data.data;
    });

    searchTxt.addEventListener('keyup', debounce(function (e) {
        searchWidget();
    }, 300));

    tuneBtn.addEventListener('click', () => {
        dialog.open();
        slider = new mdc.slider.MDCSlider(document.querySelector('.mdc-slider'));
        // if (slider.value === 0) while (slider.value < 25) slider.stepUp(1);
        dialog.listen("MDCDialog:opened", () => {
            slider.layout();
        });
    });

    buildfire.deeplink.getData((data) => {
        if (data && data.userId) {
            TaxProfessionals.get(data.userId, (err, user) => {
                currentUser = user;
                navigateTo("detailsScreen");
                buildfire.messaging.sendMessageToControl({ type: 'navigation', state: 'edit', open: currentUser.id });
            });
        }
    });
};

buildfire.publicData.onUpdate(function (event) {
    searchWidget();
});

const findUsers = (filters) => {
    if (listScreen.classList.contains('empty_state')) listScreen.classList.remove('empty_state');
    if (listScreen.classList.contains('waiting_for_location')) listScreen.classList.remove('waiting_for_location');
    if (!hasMore && !loading) userList.innerHTML = '';
    get();

    function get() {
        filters.pageSize = 50, filters.page = page;
        TaxProfessionals.search(filters, (err, taxProfessionals) => {
            if (err) return console.error(err);
            if (listScreen.classList.contains('search_users')) listScreen.classList.remove('search_users');
            if (taxProfessionals.totalRecord === 0) return listScreen.classList.add('empty_state');
            else users = users.concat(taxProfessionals.result);
            if (users.length < taxProfessionals.totalRecord) hasMore = true;
            else hasMore = false;
            taxProfessionals.result.map(item => appendUser(item));
            users = users;
            buildfire.components.ratingSystem.injectRatings({ hideAverage: true, showRatingsOnClick: false }, console.log);
            loading = false;
        });
    }
};

const loadMore = () => {
    if (!hasMore) return;
    page++;
    loading = true;
    searchFilter();
};

const appendUser = (user) => {
    let returns;
    if (user.taxReturnsFiled && user.taxReturnsFiled != 0) {
        let text = moneyValue(user.taxReturnsFiled);
        returns = (text != "none") ? (text + "+ Prepared Returns") : text;

    }
    else returns = "&#xa0;";
    user.profileImage = user.profileImage.trim() ? buildfire.imageLib.cropImage(user.profileImage, { size: 's', aspect: '1:1' }) : "../../../../../styles/media/avatar-placeholder.png";
    let profileImage = `<img src=${user.profileImage} class="profile-image"></img>`;
    let jackPro = user.isPro ? `<div class="mdc-chip" role="row">
    <div class="mdc-chip__ripple"></div>
    <span role="gridcell">
      <span role="button" tabindex="0" class="mdc-chip__danger-action">
        <span class="mdc-chip__text">JACK PRO</span>
      </span>
    </span>
    </div>`: '';
    let li = document.createElement('li');
    li.className = 'mdc-list-item';
    li.id = user.id;
    li.innerHTML = `
    <span class="mdc-list-item__ripple"></span>
    <span class="mdc-list-item__graphic material-icons" aria-hidden="true">${profileImage}</span>
    <span class="mdc-list-item__text" id="${user.id}">
    <span class="mdc-list-item__primary-text" id="${user.id}"><div class="full-name">${user.firstName} ${user.lastName} </div>${jackPro}</span>
    <span class="mdc-list-item__secondary-text double-row" id="${user.id}">
        <div class="address_field">${user.address}</div>
        <div class="returns_field">${returns}</div>
        <div class="rating" data-rating-id="${user.id}"></div>
    </span>
    </span>`;
    li.addEventListener('click', () => {
        currentUser = user;
        navigateTo('detailsScreen');
        buildfire.messaging.sendMessageToControl({ type: 'navigation', state: 'edit', open: user.id });

    });
    if (document.querySelectorAll("#userList li").length == 0) {
        let separatorTop = document.createElement('li');
        separatorTop.setAttribute("role", "separator");
        separatorTop.classList = "mdc-list-divider";
        document.getElementById('userList').appendChild(separatorTop);
    }
    let separatorBottom = document.createElement('li');
    separatorBottom.setAttribute("role", "separator");
    separatorBottom.classList = "mdc-list-divider";
    document.getElementById('userList').appendChild(li);
    document.getElementById('userList').appendChild(separatorBottom);
};

buildfire.navigation.restoreBackButtonClick();
var goBack = buildfire.navigation.onBackButtonClick;
var myBackButton = function () {
    if (pageChecker == 1) {
        pageChecker = 0;
        currentUser = null;
        navigateTo('listScreen');
        buildfire.messaging.sendMessageToControl({ type: 'navigation', state: 'list', open: -1 });
    }
    else {
        goBack();
    }
};
buildfire.navigation.onBackButtonClick = myBackButton;

const navigateTo = (screenId) => {
    let listScreen = document.getElementById("listScreen");
    let detailsScreen = document.getElementById("detailsScreen");
    let element = document.getElementById('scrollControl');

    switch (screenId) {
        case "listScreen":
            pageChecker = 0;
            clearBreadCrumbs(() => {
                listScreen.style.display = "block";
                detailsScreen.style.display = "none";
                element.scrollTop = savedScroll;
            });
            break;

        case "detailsScreen":
            element.scrollTop = 0;
            pageChecker = 1;
            // renderRatingComponent();
            renderUser();
            renderRatingComponent();

            buildfire.history.push("Profile Details");

            /* buildfire.navigation.onBackButtonClick = () => {
                 navigateTo("listScreen");
                 buildfire.navigation.restoreBackButtonClick();
             };*/

            detailsScreen.style.display = "block";
            listScreen.style.display = "none";
            break;

        default:
            break;
    }
};

const renderUser = () => {
    let fullName = currentUser.firstName + ' ' + currentUser.lastName;
    let displayGrid = false;
    buildfire.analytics.trackAction('country_' + currentUser.state, { _buildfire: { aggregationValue: 1 } });
    buildfire.analytics.trackAction('user_' + fullName, { _buildfire: { aggregationValue: 1 } });
    let toTrack = currentUser.isPro ? 'jackPro' : 'nonJackPro';
    buildfire.analytics.trackAction(toTrack, { _buildfire: { aggregationValue: 1 } });
    userName.innerHTML = fullName;
    let locationAddress = document.getElementById("locationAddress");
    if (currentUser.address && currentUser.address.length > 0) {
        locationAddress.style.display = "flex";
        userLocation.innerHTML = currentUser.address;
    } else locationAddress.style.display = "none";
    userLanguages.innerHTML = currentUser.languages.join(", ");

    let languagesTest = document.getElementById("languagesTest");
    let serviceText = document.getElementById("serviceText");

    if (currentUser.languages && currentUser.languages.length > 0) {
        languagesTest.style.display = "block";
        displayGrid = true;
    }
    else
        languagesTest.style.display = "none";

    if (currentUser.serviceTypes && currentUser.serviceTypes.length > 0) {
        serviceText.style.display = "block";
        displayGrid = true;
    }
    else
        serviceText.style.display = "none";

    let crtSeparator = document.getElementById("crtSeparator");
    if (currentUser.taxReturnsFiled && currentUser.taxReturnsFiled > 0) {
        taxReturnsFiledContainer.style.display = "block";
        displayGrid = true;
        let text = moneyValue(currentUser.taxReturnsFiled);
        userTaxReturns.innerHTML = (text != "none") ? ("<b>" + text + "+</b> Prepared returns") : text;
    } else {
        taxReturnsFiledContainer.style.display = "none";
    }

    let dataGrid = document.getElementById("dataGrid");
    if (displayGrid)
        dataGrid.style.display = "block";
    else
        dataGrid.style.display = "none";

    let jackProBadge = document.getElementById("jackPro");
    if (currentUser.isPro) {
        jackProBadge.style.display = "block";
    } else {
        jackProBadge.style.display = "none";
    }
    userWork.innerHTML = currentUser.serviceTypes.join(", ").replace("inoffice", "in-office");
    userBio.innerHTML = currentUser.description;
    if (currentUser.description && currentUser.description.length > 0)
        userBio.style.paddingTop = "10px";
    else
        userBio.style.paddingTop = "0px";
    userImage.src = currentUser.profileImage;
    if (currentUser.certificates.length != 0) {
        crtSeparator.style.display = "block";
        certificates.style.display = "block";
        certificates.innerHTML = '<p class="certificate-text">Certifications</p>';
        let first = "cert2", second = "cert3";
        currentUser.certificates.sort(function (x, y) { return x == second ? -1 : y == second ? 1 : 0; }).
            sort(function (x, y) { return x == first ? -1 : y == first ? 1 : 0; });
        currentUser.certificates.map(cert => {
            let span = document.createElement('span');
            span.style.backgroundImage = `url('images/${cert}.svg   ')`;
            span.className = 'certificate';
            span.addEventListener("click", () => {
                const options = {
                    text: certMap[cert]
                };

                const callback = () => { };
                buildfire.components.toast.showToastMessage(options, callback);
                setTimeout(() => {
                    buildfire.components.toast.closeToastMessage({ force: true });
                }, 2500);
            });
            certificates.appendChild(span);
        });
    } else { certificates.style.display = "none"; crtSeparator.style.display = "none"; }
    let contactButton = document.getElementById("contact");
    if (currentUser.buildfireUser && currentUser.buildfireUser.userId) {
        contactButton.style.display = "block";
    } else {
        contactButton.style.display = "none";
    }
};


var mySet = closeRatingsScreen;
closeRatingsScreen = () => {
    clearBreadCrumbs(() => {
        mySet();
    });
};

const moneyValue = (value) => {
    let text;
    if (value && value != 0) {
        let toNumber = Number(value);
        if (toNumber > 999999999999999) text = "none";
        else if (toNumber > 999999999999) text = ((toNumber / 1000000000000).toFixed(0) + "t");
        else if (toNumber > 999999999) text = ((toNumber / 1000000000).toFixed(0) + "b");
        else if (toNumber > 999999) text = ((toNumber / 1000000).toFixed(0) + "m");
        else if (toNumber > 9999) text = ((toNumber / 1000).toFixed(0) + "k");
        else text = value;
    }
    return text;
};
const renderRatingComponent = () => {
    let ratingComponent = document.getElementById("ratingComponent");
    let addRating = document.getElementById("addRating");
    let viewAllButton = document.getElementById("viewAllButton");
    buildfire.auth.getCurrentUser((err, loggedUser) => {
        ratingComponent.dataset.ratingId = currentUser.id;
        if (currentUser)
            buildfire.components.ratingSystem.injectRatings({ elements: [ratingComponent], hideAverage: true, showRatingsOnClick: true });
        viewAllButton.onclick = () => ratingComponent.click();
        addRating.onclick = () => ratingComponent.click();
    });

};

const contactUser = () => {
    let wallId = null;
    buildfire.auth.getCurrentUser((err, loggedUser) => {
        if (err) console.log(err);
        if (!loggedUser) {
            buildfire.auth.login({ allowCancel: false }, (err, loggedUser) => {
                if (!loggedUser) authManager.enforceLogin();
                navigate(loggedUser);
            });
        } else navigate(loggedUser);
    });

    function navigate(loggedUser) {
        buildfire.analytics.trackAction('contact', { _buildfire: { aggregationValue: 1 } });
        UserShared.isUserCusomer(currentUser.buildfireUser.username, loggedUser.email, (err, isCustomer) => {
            let user1Id = loggedUser._id;
            let user2Id = currentUser.buildfireUser ? currentUser.buildfireUser.userId : null;
            if (!user1Id || !user2Id) return console.error("User ids not defined");
            if (user1Id === user2Id) return buildfire.components.toast.showToastMessage({ text: "You can't contact yourself." }, () => { });
            let userIds = [];
            if (user1Id > user2Id) {
                wallId = user1Id + user2Id;
                userIds = [user1Id, user2Id];
            } else {
                wallId = user2Id + user1Id;
                userIds = [user2Id, user1Id];
            }

            let reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            currentUser.displayName = currentUser.firstName;
            if (reg.test(currentUser.displayName)) currentUser.displayName = 'Someone';
            let title = loggedUser.displayName + ' | ' + currentUser.displayName;
            let actionItem;
            if (!isCustomer) {
                actionItem = {
                    "type": "navigation",
                    "action": "linkToApp",
                    //"pluginId": "600e25b9-b1cd-46f5-ac28-b3a0703ccaf2", BookMe QA Version
                    "pluginId": "0be37960-5ebe-401a-8750-2fbe8d9ad7ed", //Prod Version
                    "title": "Booking",
                    "iconUrl": "https://alnnibitpo.cloudimg.io/bound/160x80/n/https://s3-us-west-2.amazonaws.com/imageserver.prod/32f6b63d-50d1-11e9-8fc5-06e43182e96c/asdasd.png",
                    "queryString": "bookingUrl=" + currentUser.bookingUrl
                };
            } else {
                actionItem = {
                    "type": "navigation",
                    "action": "linkToApp",
                    "pluginId": "efd0b9fc-9875-44da-ad18-2256a710f6fe",
                    "title": "Files",
                    "iconUrl": "https://pluginserver.buildfire.com/plugins/4e97861a-2a10-4205-8d47-cdaaae690eff/resources/icon.png",
                    "queryString": "createFolder=" + title + " Shared Folder"
                };
            }
            actionItem = JSON.stringify(actionItem);
            buildfire.navigation.navigateTo({
                pluginId: "b15c62f2-7a99-48dc-a37a-e42d46bd3289",
                title,
                queryString: `wid=${wallId}&title=${title}&actionItem=${actionItem}&sendPNTo=${JSON.stringify(userIds)}`
            });
        });
    }
};

const filterParameter = (params) => {
    let btn = document.getElementById(params);
    let span = document.getElementById((params + "2"));
    if (span.classList.contains('active-color')) {
        span.classList.remove('active-color');
    }
    else {
        span.classList.add('active-color');
    }
    if (btn.classList.contains('active-button')) {
        btn.classList.remove('active-button');
        searchParams = searchParams.filter(param => param !== params);
    }
    else {
        btn.classList.add('active-button');
        searchParams.push(params);
    }
};

const searchWidget = () => {
    userList.innerHTML = ''; users = []; page = 0;
    let listScreen = document.getElementById("listScreen");
    if (listScreen.classList.contains('empty_state')) listScreen.classList.remove('empty_state');
    if (listScreen.classList.contains('waiting_for_location')) listScreen.classList.remove('waiting_for_location');
    listScreen.classList.add("search_users");
    searchFilter();
};

const searchFilter = () => {
    let distance = (Number(25 * 1.609344)) * 1000;
    if (slider && slider.value !== 0) distance = (Number(slider.value * 1.609344)) * 1000;
    let arr = [{ "_buildfire.index.array1": 1 }];
    if (loggedUserLocation && slider && slider.value > 0) {
        console.log(loggedUserLocation);
        arr.push({
            "_buildfire.geo": {
                "$near": {
                    "$geometry": {
                        "type": "Point",
                        "coordinates": loggedUserLocation
                    },
                    "$maxDistance": distance
                }
            }
        });
    } else if (loggedUserLocation) {
        console.log(loggedUserLocation);
        arr.push({
            "_buildfire.geo": {
                "$near": {
                    "$geometry": {
                        "type": "Point",
                        "coordinates": loggedUserLocation
                    },
                    "$maxDistance": 1000000000000
                }
            }
        });
    }
    searchParams.map(param => arr.push({ "_buildfire.index.array1": param }));
    if (searchTxt.value.trim().length)
        arr.push({ "_buildfire.index.string1": { $regex: searchTxt.value, $options: 'i' } });
    findUsers({ filter: { $and: arr } });
};

const resetFilters = () => {
    users = []; page = 0;
    searchParams.map(param => {
        let btn = document.getElementById(param);
        if (btn.classList.contains('active-button')) btn.classList.remove('active-button');
        let span = document.getElementById((param + "2"));
        if (span.classList.contains('active-color')) span.classList.remove('active-color');
    });
    searchParams = [];
    searchTxt.value = '';
    slider.value = 0;
    dialog.close();
    searchFilter();
};


