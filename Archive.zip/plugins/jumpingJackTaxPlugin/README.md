# jumpingJackTaxPlugin
Private to a client jumping Jack Tax
