class TaxProfessional {
  constructor(record = {}) {
    if (!record.data) record.data = {};
    this.id = record.id || undefined;
    this.isActive =
      typeof record.data.isActive === "boolean" ? record.data.isActive : true;
    this.createdOn = record.data.createdOn || undefined;
    this.createdBy = record.data.createdBy || undefined;
    this.lastUpdatedOn = record.data.lastUpdatedOn || undefined;
    this.lastUpdatedBy = record.data.lastUpdatedBy || undefined;
    this.deletedOn = record.data.deletedOn || undefined;
    this.deletedBy = record.data.deletedBy || undefined;

    this.firstName = record.data.firstName || "";
    this.lastName = record.data.lastName || "";
    this.address = record.data.address || "";
    this.location = record.data.location || null;
    this.state = record.data.state || "";
    this.isPro =
      typeof record.data.isPro == "boolean" ? record.data.isPro : false;
    this.taxReturnsFiled = record.data.taxReturnsFiled || 0;
    this.bookingUrl = record.data.bookingUrl || "";
    this.profileImage = record.data.profileImage || "";
    this.description = record.data.description || "";
    this.languages = record.data.languages || [];
    this.serviceTypes = record.data.serviceTypes || [];
    this.certificates = record.data.certificates || [];
    this.averageRating = record.data.averageRating || null;
    this.buildfireUser = record.data.buildfireUser || null;
  }

  /**
   * Get instance ready for data access with _buildfire index object
   */
  toJSON() {
    let geoData = this.location && this.location.lat ? { type: "Point", coordinates: [this.location.lng, this.location.lat] } : undefined;

    return {
      id: this.id,
      isActive: this.isActive,
      createdOn: this.createdOn,
      createdBy: this.createdBy,
      lastUpdatedOn: this.lastUpdatedOn,
      lastUpdatedBy: this.lastUpdatedBy,
      deletedOn: this.deletedOn,
      deletedBy: this.deletedBy,
      firstName: this.firstName,
      lastName: this.lastName,
      address: this.address,
      location: this.location,
      state: this.state,
      isPro: this.isPro,
      taxReturnsFiled: this.taxReturnsFiled,
      bookingUrl: this.bookingUrl,
      profileImage: this.profileImage,
      description: this.description,
      languages: this.languages,
      serviceTypes: this.serviceTypes,
      certificates: this.certificates,
      averageRating: this.averageRating,
      buildfireUser: this.buildfireUser,
      _buildfire: {
        index: {
          array1: [
            this.deletedBy ? 3 : 2,
            this.isActive ? 1 : 0,
            ...this.serviceTypes,
            ...this.languages,
          ],
          string1: this.firstName + " " + this.lastName,
        },
        geo: geoData
      },
    };
  }
}
