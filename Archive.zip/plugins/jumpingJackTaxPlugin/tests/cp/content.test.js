class ContentTests {
  static run(loggedInUser) {
    logInfo("Running Content Tests");

    test("Add Tax Professional", () => {
      const taxPro = new TaxProfessional();
      taxPro.fullName = "John Doe";
      taxPro.languages = ["eng", "spa"];

      TaxProfessionals.add(loggedInUser, taxPro, (err, addedUser) => {
        console.log(err, addedUser);
        expect(
          "Added tax professional",
          addedUser && addedUser.fullName === taxPro.fullName
        );
        test2(addedUser.id);
      });
    });

    let test2 = (id) =>
      test("Gets Tax professional", () => {
        TaxProfessionals.get(id, (err, taxPro) => {
          console.log(taxPro.id, id);
          expect("Got tax professional", taxPro && taxPro.id === id);
          test3(taxPro);
        });
      });

    let test3 = (taxPro) =>
      test("Edits Tax professional", () => {
        taxPro.fullName = "Jane Doe";

        TaxProfessionals.set(loggedInUser, taxPro, (err, updatedTaxPro) => {
          expect(
            "Edited Tax Professional",
            updatedTaxPro && updatedTaxPro.fullName === taxPro.fullName
          );
          test4();
        });
      });

    let test4 = () =>
      test("Finds all tax professionals", () => {
        TaxProfessionals.search(
          { filter: { "_buildfire.index.array1": 1 } },
          (err, taxProfessionals) => {
            expect(
              "Gets all tax professionals",
              taxProfessionals && taxProfessionals.length
            );
            taxProfessionals.forEach(test5);
          }
        );
      });

    let test5 = (taxPro) =>
      test("Deletes Tax professional", () => {
        TaxProfessionals.del(loggedInUser, taxPro, (err, deletedTaxpro) => {
          expect(
            "Deleted tax professional",
            deletedTaxpro && deletedTaxpro.isActive === false
          );
        });
      });
  }
}
