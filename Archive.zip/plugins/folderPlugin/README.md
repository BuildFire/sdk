# Folder Plugin ![](https://api.travis-ci.org/BuildFire/folderPlugin.svg)


## Development
Run `npm install` to install dev dependencies.

## Deployment
Run `npm start` to create a release folder. The new folder will be named `folderPlugin_release`. 
Use a zip of this folder when you upload your plugin to the developer portal.

