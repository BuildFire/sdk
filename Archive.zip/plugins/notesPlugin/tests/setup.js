function runTests() {
  console.log("RUNNING TESTS")
  buildfire.auth.getCurrentUser((err, result) => {
    if (err) return err;
    if (result == null) {
      buildfire.auth.login({ allowCancel: false }, (err, result) => {
        if (err) return console.error(err);
        logInfo("Running Control Panel tests");
        executeTests(result);
      });
    } else {
      logInfo("Running Control Panel tests");

      executeTests(result);
    }
  });
}

function executeTests(user) {
  ContentTests.run(user);
}