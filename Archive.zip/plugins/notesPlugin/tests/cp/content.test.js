class ContentTests {
  static run(loggedInUser) {
    logInfo("Running Content Tests");
    test("Add Note", () => {
      const note = new Note();
      note.noteHTML =
        "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec leo eros, viverra a condimentum ut, rutrum vel risus. Praesent ullamcorper nec urna id congue. Vestibulum in mauris eu nulla tincidunt consectetur. Vivamus bibendum porta erat, vel porttitor magna aliquam vel. Curabitur porttitor vel diam vel vehicula. Vivamus in rhoncus ipsum, non blandit leo. Nam nec odio porttitor enim condimentum feugiat id non nibh. Vestibulum nec condimentum mauris, sit amet pellentesque ante. Vestibulum fringilla dolor at arcu ultricies elementum. Curabitur ac nibh sit amet ligula finibus maximus. Praesent tincidunt tortor non metus egestas convallis. Phasellus nec tellus odio. Maecenas ultricies ante non finibus pulvinar./p>";
      note.permissions = {
        read: [],
        write: [],
        admin: [loggedInUser._id],
        delete: [],
      };

      Notes.add(note, (err, note) => {
        expect("Added note", note && note.noteHTML);
        test2(loggedInUser, note);
      });
    });

    let test2 = (loggedInUser, note) =>
      test("Gets All Notes", () => {
        Notes.get(loggedInUser._id, 0, 50, (err, notes) => {
          console.log(notes);
          expect("Got Notes", notes && notes.length);
          test3(note.id);
        });
      });

    let test3 = (id) =>
      test("Gets Note", () => {
        Notes.getSingle(id, (err, note) => {
          expect("Got Note", note && note.id === id);
          test4(note);
        });
      });

    let test4 = (note) =>
      test("Edits Note", () => {
        note.noteHTML = "<p>Edited note body for testing purposes</p>";

        Notes.set(note, (err, editedNote) => {
          expect(
            "Edited Note",
            editedNote && editedNote.noteHTML === note.noteHTML
          );
          test5(note);
        });
      });

    let test5 = (note) =>
      test("Pins Note", () => {
        Notes.pin(note, (err, pinnedNote) => {
          expect("Pinned Note", pinnedNote.pinnedOn !== null);
          test6();
        });
      });

    let test6 = () =>
      test("Finds pinned notes", () => {
        Notes.getPinned(loggedInUser._id, (err, pinnedNotes) => {
          expect("Gets pinned notes", pinnedNotes && pinnedNotes.length);
          test7();
        });
      });

    let test7 = () =>
      test("Finds all notes", () => {
        Notes.search(loggedInUser._id, "body", (err, notes) => {
          expect("Gets all notes", notes && notes.length);
          notes.forEach((note) => {
            if (note.isActive) test8(note);
          });
        });
      });

    let test8 = (note) =>
      test("Deletes note", () => {
        Notes.del(note, (err, deletedNote) => {
          expect(
            "Deleted Notes",
            deletedNote && deletedNote.isActive === false
          );
        });
      });
  }
}
