//global variables
const state = {
  loggedInUser: null,
  id: null,
  pinned: null,
  pinnedLength: 0,
  allNotes: null,
  notesArray: [],
  pinnedArray: [],
  limit: 50,
  totalRecord: 0,
  skip: 0,
};

let colors = {};
let searchField;
let searchTerm = "";

buildfire.appearance.titlebar.show();
buildfire.appearance.getAppTheme(function (err, response) {
  if (response.colors) {
    colors = response.colors;
    document.getElementById("searchContainer").style.background =
      colors.footerMenuBackgroundColor;
    document
      .getElementById("searchTxt")
      .setAttribute("style", `color: ${colors.bodyText}  !important`);
  }
});

authManager.enforceLogin();

authManager.onUserChange = (user) => {
  state.loggedInUser = user;
  state.id = state.loggedInUser._id;
  init();
};

function init() {
  if (state.loggedInUser) state.id === state.loggedInUser._id;
  state.notesArray = [];
  state.pinnedArray = [];
  searchField = document.getElementById("searchTxt");
  searchField.value = "";
  searchField.placeholder = strings.get("notesUI.searchPlaceholder");
  document.getElementById("searchResults").style.display = "none";
  document.getElementById("clear").style.display = "none";
  document
    .querySelector("input[type=text]")
    .style.setProperty("--c", `${colors.bodyText}`);

  searchField.onkeypress = debounce(function (e) {
    search(state.id, searchField.value);
  }, 500);
  clearBox("pinnedItems");
  clearBox("items");
  createHeader("items");
  createPinnedHeader("pinnedItems");
  getPinnedNotes(state.id);
  getAll(state.id, (state.skip = 0), 10);
  if (
    (state.pinned === false && state.allNotes === false) ||
    (state.pinned === undefined && state.allNotes === undefined) ||
    document.getElementById("mainContent").innerHTML === ""
  ) {
    document.getElementById("items").style.display = "none";
    document.getElementById("pinnedItems").style.display = "none";
    document.getElementById("emptyState").classList.add("emptyStateShow");
  }
}

document.getElementById("mainContent").onscroll = lazyLoad;
if (document.getElementById("mainContent").innerHTML === "")
  document.getElementById("emptyState").classList.add("emptyStateShow");
//gets pinned notes and makes ui elements to display them on the widget
function getPinnedNotes(id, totalRecord) {
  console.log("get pinned");
  let pinnedItems = document.getElementById("pinnedItems");
  Notes.getPinned(state.id, (err, pinnedNotes) => {
    if (!pinnedNotes.length) {
      state.pinned = false;
      document.getElementById("pinnedItems").style.display = "none";
      document.getElementById("notesHeader").style.display = "none";
    } else {
      state.pinned = true;
      document.getElementById("pinnedHeader").style.display = "block";
      document.getElementById("items").style.paddingTop = "5px";
      document.getElementById("pinnedItems").style.display = "block";
      document.getElementById("pinnedItems").style.paddingTop = "15px";
      document.getElementById("pinnedItems").style.paddingBottom = "10px";
      pinnedNotes.forEach((pinnedNote) => {
        let pinnedNoteUI = createNoteRow(pinnedNote);
        pinnedItems.appendChild(pinnedNoteUI);
      });
    }
    if (state.pinned && state.allNotes === false) {
      document.getElementById("items").style.display = "none";
      document.getElementById("emptyState").classList.remove("emptyStateShow");
      document.getElementById("notesHeader").style.display = "none";
    }
    if (state.pinned && state.allNotes === true) {
      document.getElementById("notesHeader").style.display = "block";
    }
    state.pinnedArray = [...state.pinnedArray, ...pinnedNotes];
  });
}

//gets all notes and makes ui elements to display them on the widget
function getAll(id, skip, limit) {
  let items = document.getElementById("items");
  console.log("getall");
  Notes.get(state.id, state.skip, state.limit, (err, notes, totalRecord) => {
    console.log(notes);
    if (notes.length > 0) {
      state.allNotes = true;
      state.totalRecord = totalRecord;
      document.getElementById("emptyState").classList.remove("emptyStateShow");
      items.style.display = "block";
    } else if (
      !notes.length &&
      state.notesArray.length === 0 &&
      state.pinnedArray.length === 0
    ) {
      state.allNotes = false;
      items.style.display = "none";
    }
    notes.forEach((note, index) => {
      let noteUI = createNoteRow(note);
      items.appendChild(noteUI);
      noteUI.style.animationDelay = index * 100 + "ms";
    });
    if (state.allNotes === true && state.pinned === true) {
      document.getElementById("notesHeader").style.display = "block";
    }
    if (state.allNotes === true && state.pinned === false) {
      document.getElementById("notesHeader").style.display = "none";
    }
    if (state.allNotes === false && state.pinned === false) {
      document.getElementById("items").style.display = "none";
      document.getElementById("emptyState").classList.add("emptyStateShow");
      document
        .getElementById("emptyState")
        .setAttribute("style", `color: ${colors.bodyText}  !important`);
    }
    state.notesArray = [...state.notesArray, ...notes];
    state.skip = state.notesArray.length;
    console.log(state.allNotes);
  });
}

function search(id, searchTerm) {
  let searchResults = document.getElementById("searchResults");
  searchResults.innerHTML = "";
  Notes.search(state.id, searchTerm, (err, results) => {
    if (err || !results) return;
    pinnedItems.style.display = "none";
    items.style.display = "none";
    results.forEach((result) => {
      let noteUI = createNoteRow(result);
      searchResults.appendChild(noteUI);
    });
    if (!results.length) {
      searchResults.style.display = "block";
      let oldNoResults = document.getElementById("no-results");
      if (oldNoResults) oldNoResults.parentElement.removeChild(oldNoResults);
      let noResults = document.createElement("p");
      noResults.innerHTML = "";
      noResults.setAttribute("id", "no-results");

      noResults.innerHTML = strings.get("notesUI.emptySearch");
      document.getElementById("emptyState").classList.remove("emptyStateShow");
      searchResults.appendChild(noResults);
    } else {
      document.getElementById("searchResults").style.display = "block";
    }
  });
  if (searchTerm) {
    document.getElementById("clear").style.display = "flex";
    document.getElementById("clear").onclick = () => {
      document.getElementById("searchResults").style.display = "none";
      document.getElementById("clear").style.display = "none";
      searchField.value = "";
      init();
    };
  }
}

//opens buildFire input to allow user to create or edit a note
function createOrEditNote(note = new Note()) {
  let options = {
    placeholder: strings.get("inputAPI.inputPlaceholder"),
    saveText: strings.get("inputAPI.inputSaveBtn"),
    maxLength: 5000,
    wysiwyg: true,
    attachments: {
      images: { enable: true, multiple: true },
      gifs: { enable: true },
    },
    defaultAttachments: { images: [...note.images], gifs: [...note.gifs] },
  };

  if (note && note.noteHTML) {
    options.defaultValue = note.noteHTML;
  };


  let callback = (e, response) => {
    if (e || response.cancelled) return;
    const result = response.results[0];
    if (result.gifs) {
      result.gifs = result.gifs.map((gif) => gif.images.downsized_medium.url);
    }

    note.noteHTML = response.results[0].wysiwygValue;
    note.images = [...result.images];
    note.gifs = [...result.gifs];
    if (note.id) {
      Notes.set(note, () => {
        init();
      });
    } else {
      Notes.add(note, () => {
        init();
      });
    }
  };
  buildfire.input.showTextDialog(options, callback);
  init();
}
