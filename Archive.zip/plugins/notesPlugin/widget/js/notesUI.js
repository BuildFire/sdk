//function that creates UI element to display note on widget
function createNoteRow(note) {
  let container = document.createElement("div");
  container.classList.add("note-row");
  container.setAttribute("id", `${note.id}`);
  container.style.background = colors.footerMenuBackgroundColor;
  let image = document.createElement("img");

  if (note.images && note.images.length) {
    image.className = "note-image";
    image.src = buildfire.imageLib.resizeImage(note.images[0], {
      size: "m",
      aspect: "1:1",
    });
  }
  if (note.images && note.images.length > 1) {
    image.classList.add("note-image-multiple");
  }
  if (note.gifs && note.gifs.length) {
    image.className = "note-image";
    image.src = buildfire.imageLib.resizeImage(note.gifs[0], {
      size: "m",
      aspect: "1:1",
    });
  }

  //options button for note
  const actionHolder = document.createElement("div");
  actionHolder.classList = "action-holder";
  const actionIcon = document.createElement("span");
  actionIcon.classList = "glyphicon glyphicon-option-vertical glyphicon-touch";
  actionHolder.appendChild(actionIcon);
  actionIcon.onclick = () => {
    openDrawer(note);
  };
  //end options button

  let noteCreatedTime = new Date(note.lastUpdatedOn).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  let noteView = document.createElement("div");
  let noteText = document.createElement("p");
  let noteDate = document.createElement("p");
  noteView.classList.add("note-body");
  noteDate.classList.add("note-date");
  noteText.classList.add("note-text");
  noteView.style.background = colors.footerMenuBackgroundColor;
  noteText.innerHTML =
    note.notePlainText || strings.get("notesUI.emptyNotePlaceholder");
  noteDate.innerHTML =
    isTodayOrYesterday(note.lastUpdatedOn) + ", " + noteCreatedTime;
  noteView.onclick = () => {
    clearBox("items");
    clearBox("pinnedItems");
    createOrEditNote(note);
  };
  container.appendChild(noteView);
  if ((note.images && note.images.length) || (note.gifs && note.gifs.length)) {
    container.appendChild(image);
  }
  noteView.appendChild(noteText);
  noteView.appendChild(noteDate);
  container.appendChild(actionHolder);
  return container;
}

function createHeader(elementID) {
  let parent = document.getElementById(elementID);
  let notesHeader = document.createElement("h4");
  notesHeader.setAttribute("id", "notesHeader");
  notesHeader.innerHTML = strings.get("notesUI.headerText");
  parent.prepend(notesHeader);
}
function createPinnedHeader(elementID) {
  let pinnedHeader = document.createElement("h4");
  pinnedHeader.setAttribute("id", "pinnedHeader");
  pinnedHeader.innerHTML = strings.get("notesUI.pinnedHeaderText");
  document.getElementById(elementID).appendChild(pinnedHeader);
}
