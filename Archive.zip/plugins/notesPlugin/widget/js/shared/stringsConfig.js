const stringsConfig = {
  notesUI: {
    title: "Notes List",
    labels: {
      emptyStatePlaceholder1: {
        title: "No entries placeholder text - first line",
        placeholder: "You don't have any notes yet.",
        maxLength: 30,
        defaultValue: "You don't have any notes yet.",
      },
      emptyStatePlaceholder2: {
        title: "No entries placeholder text - second line",
        placeholder: 'Tap "+" to add a new note.',
        maxLength: 30,
        defaultValue: 'Tap "+" to add a new note.',
      },
      headerText: {
        title: "Header text for the notes section",
        placeholder: "Notes",
        maxLength: 30,
        defaultValue: "Notes",
      },
      pinnedHeaderText: {
        title: "Header text for the pinned notes section",
        placeholder: "Pinned",
        maxLength: 30,
        defaultValue: "Pinned",
      },
      searchPlaceholder: {
        title: "Placeholder for search field",
        placeholder: "Search Notes",
        maxLength: 30,
        defaultValue: "Search Notes",
      },
      emptySearch: {
        title: "No search results found info text",
        placeholder: "No Search Results Found.",
        maxLength: 30,
        defaultValue: "No Search Results Found.",
      },
      emptyNotePlaceholder: {
        title: "Placeholder text for empty note",
        placeholder: "No additional text",
        maxLength: 30,
        defaultValue: "No additional text",
      },
    },
  },
  inputAPI: {
    title: "Note",
    labels: {
      inputPlaceholder: {
        title: "Note placeholder",
        placeholder: "Note",
        maxLength: 50,
        defaultValue: "Note",
      },
      inputSaveBtn: {
        title: "Save button text",
        placeholder: "Save",
        maxLength: 10,
        defaultValue: "Save",
      },
    },
  },
  deleteModal: {
    title: "Delete Confirmation Modal",
    labels: {
      modalTitle: {
        title: "Delete confirmation modal title text",
        placeholder: "Are You Sure?",
        maxLength: 30,
        defaultValue: "Are You Sure?",
      },
      modalBody: {
        title: "Delete confirmation modal body text",
        placeholder: "Are you sure you want to delete this note?",
        maxLength: 60,
        defaultValue: "Are you sure you want to delete this note?",
      },
      modalConfirmBtn: {
        title: "Confirm delete button text",
        placeholder: "Yes",
        maxLength: 10,
        defaultValue: "Yes",
      },
      modalCancelBtn: {
        title: "Cancel delete button text",
        placeholder: "No",
        maxLength: 10,
        defaultValue: "No",
      },
    },
  },
};
