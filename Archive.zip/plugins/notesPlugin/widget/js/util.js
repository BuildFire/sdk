//checks if date today or yesterday and returns that value, otherwise returns date
function isTodayOrYesterday(date) {
  date = new Date(date);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);

  date.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  yesterday.setHours(0, 0, 0, 0);

  if (date.getTime() === today.getTime()) {
    return "Today";
  } else if (date.getTime() === yesterday.getTime()) {
    return "Yesterday";
  } else return date.toLocaleDateString();
}

function truncate(str, n) {
  return str.length > n ? str.substr(0, n - 1) + "&hellip;" : str;
}

function lazyLoad() {
  const { scrollTop, clientHeight, scrollHeight } = document.getElementById(
    "mainContent"
  );
  if (
    (state.notesArray.length + state.pinnedArray.length <= state.totalRecord ||
      state.totalRecord == 0) &&
    scrollTop + clientHeight >= scrollHeight
  )
    getAll(state.id, state.skip, state.limit);
}

const debounce = (fn, time) => {
  let timeout;
  return function (...args) {
    // <-- not an arrow function
    const functionCall = () => fn.apply(this, args);
    clearTimeout(timeout);
    timeout = setTimeout(functionCall, time);
  };
};

function clearBox(elementID) {
  document.getElementById(elementID).innerHTML = "";
}

function getCount(parent, getChildrensChildren) {
  let relevantChildren = 0;
  let children = parent.childNodes.length;
  for (let i = 0; i < children; i++) {
    if (parent.childNodes[i].nodeType != 3) {
      if (getChildrensChildren)
        relevantChildren += getCount(parent.childNodes[i], true);
      relevantChildren++;
    }
  }
  return relevantChildren;
}

//opens drawer for options
function openDrawer(note) {
  let listItems;
  if (note.pinnedOn) {
    listItems = [
      { id: "1", text: "Unpin" },
      { id: "2", text: "Delete" },
    ];
  } else {
    listItems = [
      { id: "1", text: "Pin" },
      { id: "2", text: "Delete" },
    ];
  }
  buildfire.components.drawer.openBottomListDrawer(
    {
      header: "",
      content: "",
      listItems,
    },
    (err, result) => {
      if (err) return console.error(err);
      switch (result.id) {
        case "1":
          if (!note.pinnedOn) {
            Notes.pin(note, () => {
              init();
            });
            buildfire.components.drawer.closeDrawer(state.id);
          } else {
            Notes.unpin(note, () => {
              init();
            });
            buildfire.components.drawer.closeDrawer();
          }
          break;
        case "2":
          buildfire.components.drawer.closeDrawer();
          buildfire.notifications.confirm(
            {
              title: strings.get("deleteModal.modalTitle"),
              message: strings.get("deleteModal.modalBody"),
              confirmButton: {
                text: strings.get("deleteModal.modalConfirmBtn"),
                key: "yes",
                type: "danger",
              },
              cancelButton: {
                text: strings.get("deleteModal.modalCancelBtn"),
                key: "no",
                type: "default",
              },
            },
            function (e, data) {
              if ((e && e !== 2) || (data && data.selectedButton.key) == "yes")
                Notes.del(note, () => {
                  let element = document.getElementById(`${note.id}`);
                  element.remove();
                  let itemsElement = document.getElementById("items");
                  let pinnedElement = document.getElementById("pinnedItems");
                  console.log(
                    itemsElement.childNodes.length,
                    pinnedElement.childNodes.length
                  );
                  if (
                    itemsElement.childNodes.length === 1 &&
                    pinnedElement.childNodes.length === 1
                  ) {
                    itemsElement.style.display = "none";
                    pinnedElement.style.display = "none";
                    document
                      .getElementById("emptyState")
                      .classList.add("emptyStateShow");
                  }
                  if (itemsElement.childNodes.length === 1) {
                    itemsElement.style.display = "none";
                  }
                  if (pinnedElement.childNodes.length === 1) {
                    pinnedElement.style.display = "none";
                  }
                });
            }
          );
          break;
      }
    }
  );
}
