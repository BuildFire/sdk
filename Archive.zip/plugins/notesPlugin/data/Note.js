class Note {
  constructor(record = {}) {
    if (!record.data) record.data = {};
    this.id = record.id || undefined;
    this.isActive =
      typeof record.data.isActive === "boolean" ? record.data.isActive : true;
    this.createdOn = record.data.createdOn || undefined;
    this.createdBy = record.data.createdBy || undefined;
    this.lastUpdatedOn = record.data.lastUpdatedOn || undefined;
    this.lastUpdatedBy = record.data.lastUpdatedBy || undefined;
    this.deletedOn = record.data.deletedOn || undefined;
    this.deletedBy = record.data.deletedBy || undefined;

    this.noteHTML = record.data.noteHTML || "";
    this.images = record.data.images || [];
    this.gifs = record.data.gifs || [];
    this.pinnedOn = record.data.pinnedOn || null;
    this.archivedOn = record.data.archivedOn || null;
    this.labels = record.data.labels || [];
    this.permissions = record.data.permissions || {
      read: [],
      write: [],
      admin: [],
      delete: [],
    };
  }

  get notePlainText() {
    let noteWithoutHTML = this.noteHTML.toString();
    return noteWithoutHTML.replace(/(<([^>]+)>)/gi, "");
  }

  /**
   * Get instance ready for data access with _buildfire index object
   */
  toJSON() {
    return {
      id: this.id,
      isActive: this.isActive,
      createdOn: this.createdOn,
      createdBy: this.createdBy,
      lastUpdatedOn: this.lastUpdatedOn,
      lastUpdatedBy: this.lastUpdatedBy,
      deletedOn: this.deletedOn,
      deletedBy: this.deletedBy,
      noteHTML: this.noteHTML,
      images: this.images,
      gifs: this.gifs,
      pinnedOn: this.pinnedOn,
      archivedOn: this.archivedOn,
      labels: this.labels,
      permissions: this.permissions,
      _buildfire: {
        index: {
          date1: this.lastUpdatedOn,
          array1: [...this.labels, { ...this.permissions }],
          text: this.notePlainText,
          string1: this.createdBy,
          number1: this.pinnedOn,
        },
      },
    };
  }
}
