# Notes Plugin

Notes is a note taking feature where you can capture thoughts, write down ideas, and type text.
It allows the user to create, edit, delete, pin and search notes.
Link to the [tech spec.](https://docs.google.com/document/d/1HPn97tHMw0oKgv8TBgcY76Rs_1nEkLkvuq1CXoKPO4g/edit#heading=h.gkcec8m96nvy)

## Init

Run `npm install` to initialize the folder

## Run

When ready for final test and release run `gulp build`.
This will produce a sister folder with `_release` as a postfix on the root folder.
Test this optimized copy then zip and publish.

## Merge

If you are importing into an existing plugin project make sure you copy the `package.json` and `gulpfile.js` files when adding.

## Combine Files

To combine your JS files simply surround them with this html comment:

When ready for final test and release run `gulp build`.
This will produce a sister folder with `_release` as a postfix on the root folder.
Test this optimized copy then zip and publish.

## Merge

If you are importing into an existing plugin project make sure you copy the `package.json` and `gulpfile.js` files when adding.

## Combine Files

To combine your JS files simply surround them with this html comment:

```
<!-- build:bundleJSFiles  -->...<!-- endbuild -->
```

This will merge, minify and obfescate all files within these two comments into one JS file.

This will merge, minify and obfescate all files within these two comments into one JS file.

```
<!-- build:bundleJSFiles  -->
    <script src="../data/Note.js"></script>
    <script src="../dataAccess/Notes.js"></script>
    <script src="../dataAccess/AuthManager.js"></script>
    <script src="./js/notesUI.js"></script>
    <script src="./js/util.js"></script>
    <script src="./js/widget.js"></script>
<!-- endbuild -->
```

In the release version this will be swapped out to reference a single file

- to combine your CSS files simply surround them with this html comment:

```
<!-- build:bundleCSSFiles  -->...<!-- endbuild -->
```

this will merge, minify and obfescate all files within these two comments into one CSS file

_example:_

```
    <!-- build:bundleCSSFiles  -->
    <link rel="stylesheet" type="text/css" href="css/emptyState.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <!-- endbuild -->

```

### File Order

### File Order

if the order matters then edit the `gulpfile.js`
look for the array of tasks that need altereing.

_example:_

```
var cssTasks=[
    {name:"widgetCSS",src:"widget/**/*.css",dest:"/widget"},
    {name:"controlContentCSS",src:"control/content/**/*.css",dest:"/control/content"},
    {name:"controlDesignCSS",src:"control/design/**/*.css",dest:"/control/design},
    {name:"controlSettingsCSS",src:"control/settings/**/*.css",dest:"/control/settings"}
];
```

Looking at the first object `{name:"widgetCSS",src:"widget/**/*.css",dest:"/widget"}` lets say the CSS file order in this folder affects the outcome. All we need to do is specify the files in an array in the `src` property:

```
 {
 name:"widgetCSS",
 src:["widget/css/b.css", "widget/css/c.css", "widget/a.css"], dest:"/widget"
 }
```

## Data Structure

```
noteHTML; //raw note body text from inputAPI
images; //images added to note
gifs; //gifs added to note
pinnedOn; //timestamp when the note is pinned
archivedOn; //timestamp when the note is archived
labels; // note labels
permissions; //permissions for read, write and delete access
```

For more info please refer to the tech spec of the plugin
