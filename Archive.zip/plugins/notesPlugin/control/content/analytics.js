const registerEvents = () => {
  buildfire.analytics.registerEvent(
    {
      title: "Note Added",
      key: "note_added",
      description: "Occurs when a user makes a note",
    },
    { silentNotification: true }
  );
};
