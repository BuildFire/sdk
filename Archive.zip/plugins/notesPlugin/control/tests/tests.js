document.getElementById("runTestButton").addEventListener("click", () => {
  runTests();
});
