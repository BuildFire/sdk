class Notes {
  /**
   * Get Database Tag
   */
  static get TAG() {
    return "note";
  }

  /**
   * Get All Notes
   * @param {String} id Id of user that owns the notes
   * @param {Number} skip number of entries to skip fetching from db
   * @param {Number} limit how many entries will be fetched in single call
   * @param {Function} callback Callback function
   */
  static get(id, skip = 0, limit, callback) {
    let searchOptions = {
      filter: {
        "_buildfire.index.string1": id,
      },
      sort: {
        "_buildfire.index.date1": -1,
      },
      recordCount: true,
      skip,
      limit,
    };
    buildfire.publicData.search(
      searchOptions,
      Notes.TAG,
      (err, records, totalRecord) => {
        if (err) return callback(err);
        return callback(
          null,
          records.result
            .filter(
              (result) => result.data.pinnedOn === null && result.data.isActive
            )
            .map((result) => new Note(result)),
          (totalRecord = records.totalRecord)
        );
      }
    );
  }

  /**
   * Get Single Note
   * @param {String} id Id of note to be retreived
   * @param {Function} callback Callback function
   */
  static getSingle(id, callback) {
    buildfire.publicData.getById(id, Notes.TAG, (err, record) => {
      if (err) return callback(err);
      return callback(null, new Note(record));
    });
  }

  /**
   * Search notes
   * @param {string} id id of currently logged in user
   * @param {string} search term that will be gotten from UI
   * @param {Function} callback Callback function
   */

  static search(id, searchTerm, callback) {
    let searchOptions = {
      filter: {
        "_buildfire.index.string1": id,
        "_buildfire.index.text": { $regex: searchTerm, $options: "i" },
      },
      sort: {
        "_buildfire.index.date1": 1,
      },
    };
    buildfire.publicData.search(searchOptions, Notes.TAG, (err, records) => {
      if (err) return callback(err);
      return callback(
        null,
        records
          .filter((record) => record.data.isActive)
          .map((record) => new Note(record))
      );
    });
  }
  /**
   * Add new note
   * @param {Note} note Instance of note data class
   * @param {Function} callback Callback function
   */
  static add(note, callback) {
    buildfire.analytics.trackAction("note_added");
    if (!(note instanceof Note))
      return callback(new Error("Only Note instance can be used"));

    note.createdBy = authManager.currentUser._id;
    note.createdOn = new Date();
    note.lastUpdatedOn = new Date();
    buildfire.publicData.insert(
      note.toJSON(),
      Notes.TAG,
      false,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new Note(record));
      }
    );
  }
  /**
   * Edit single note instance
   * @param {Note} note Instance of note data class
   * @param {Function} callback Callback function
   */
  static set(note, callback) {
    if (!(note instanceof Note))
      return callback(new Error("Only Note instance can be used"));

    note.lastUpdatedOn = new Date();
    note.lastUpdatedBy = authManager.currentUser._id;

    buildfire.publicData.update(
      note.id,
      note.toJSON(),
      Notes.TAG,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new Note(record));
      }
    );
  }
  /**
   * Pin single note instance
   * @param {Note} note Instance of note data class
   * @param {Function} callback Callback function
   */
  static pin(note, callback) {
    if (!(note instanceof Note))
      return callback(new Error("Only Note instance can be used"));
    buildfire.publicData.update(
      note.id,
      {
        $set: {
          lastUpdatedBy: authManager.currentUser._id,
          pinnedOn: +new Date(),
        },
      },
      Notes.TAG,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new Note(record));
      }
    );
  }
  /**
   * Unpin single note instance
   * @param {Note} note Instance of note data class
   * @param {Function} callback Callback function
   */
  static unpin(note, callback) {
    if (!(note instanceof Note))
      return callback(new Error("Only Note instance can be used"));
    buildfire.publicData.update(
      note.id,
      {
        $set: {
          lastUpdatedBy: authManager.currentUser._id,
          pinnedOn: null,
        },
      },
      Notes.TAG,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new Note(record));
      }
    );
  }

  /**
   * Get pinned notes
   * @param {string} id id of currently logged in user
   * @param {Function} callback Callback function
   */

  static getPinned(id, callback) {
    let searchOptions = {
      filter: {
        "_buildfire.index.string1": id,
      },
      sort: {
        "_buildfire.index.date1": -1,
      },
    };
    buildfire.publicData.search(searchOptions, Notes.TAG, (err, data) => {
      if (err) return callback(err);
      return callback(
        null,
        data
          .filter(
            (result) => result.data.pinnedOn !== null && result.data.isActive
          )
          .map((result) => new Note(result))
      );
    });
  }

  /**
   * Delete single note instance
   * @param {Note} note Instance of note data class
   * @param {Function} callback Callback function
   */
  static del(note, callback) {
    if (!(note instanceof Note))
      return callback(new Error("Only Note instance can be used"));

    note.deletedBy = authManager.currentUser._id;
    note.deletedOn = new Date();
    note.isActive = false;

    buildfire.publicData.update(
      note.id,
      note.toJSON(),
      Notes.TAG,
      (err, record) => {
        if (err) return callback(err);
        return callback(null, new Note(record));
      }
    );
  }
}
